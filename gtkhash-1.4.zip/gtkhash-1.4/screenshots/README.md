## GtkHash Screenshots

### Main window and preferences:
![Main window](readme.png)

### Using drag-and-drop to select files:
![Drag and drop files](drag-and-drop-files.png)
![File list](file-list.png)

---
Screenshots by [Stéphane Gourichon](https://github.com/fidergo-stephane-gourichon), issue [#38](https://github.com/tristanheaven/gtkhash/issues/38).
