/* $Id: sample.c 19 2010-02-27 23:13:13Z jessekornblum $ */

#include <stdio.h>

int main(int argc, char **argv)
{
  printf ("I AM AN EVIL H4X0R PRGRAM!!!1!\n");
  return 1;
}
