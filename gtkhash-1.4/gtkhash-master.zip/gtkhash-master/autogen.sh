#!/bin/sh

exec autoreconf -v -Wall --force --install
